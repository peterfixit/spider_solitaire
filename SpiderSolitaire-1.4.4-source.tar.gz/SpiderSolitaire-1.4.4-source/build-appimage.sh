#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPDIR="$HERE/SpiderSolitaire.AppDir"
TOOL="$HERE/appimagetool-x86_64.AppImage"
RUNTIME="$HERE/runtime-x86_64"
OUT="$HERE/SpiderSolitaire-1.4.4-x86_64.AppImage"

if [[ ! -d "$APPDIR" ]]; then
  echo "Missing $APPDIR" >&2
  exit 1
fi
if [[ ! -x "$TOOL" ]]; then
  curl -L --fail -o "$TOOL" "https://github.com/AppImage/appimagetool/releases/download/1.9.1/appimagetool-x86_64.AppImage"
  chmod +x "$TOOL"
fi
if [[ ! -x "$RUNTIME" ]]; then
  curl -L --fail -o "$RUNTIME" "https://github.com/AppImage/type2-runtime/releases/download/20251108/runtime-x86_64"
  chmod +x "$RUNTIME"
fi
ARCH=x86_64 "$TOOL" --appimage-extract-and-run --no-appstream --runtime-file "$RUNTIME" "$APPDIR" "$OUT"
chmod +x "$OUT"
echo "Created: $OUT"
