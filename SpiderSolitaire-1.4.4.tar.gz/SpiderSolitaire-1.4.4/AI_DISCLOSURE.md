# Generative AI disclosure

Substantial portions of Spider Solitaire 1.4.4 were created with generative-AI assistance from OpenAI ChatGPT. This includes much of the Python game and user-interface code, iterative debugging changes, and Flatpak/Flathub packaging material. The project maintainer directed the features, tested builds, reported defects, and iterated on behaviour and presentation.

This disclosure is included because Flathub requires known AI-generated code, documentation, packaging, or other submitted material to be disclosed. The maintainer should review the current Flathub policy before submission and make any additional disclosure required by reviewers.
