# Spider Solitaire 1.4.4

A configurable Spider Solitaire game for Linux written in Python/Tkinter.

Features include 1/2/4-suit games, Easy/Normal/Hard deal bias, 8/16 completed-run modes, Draw 10/Draw 3 stock modes, drag-and-drop and single-click moves, undo, animated hints, statistics, appearance settings, and responsive resizing.

## Running from source

```sh
python3 spider_solitaire.py
```

Python 3 with Tkinter is required.

## Flatpak / Flathub

The upstream release includes the desktop file, AppStream metainfo, and icons required by the Flatpak manifest. The Flathub submission manifest is maintained separately from the upstream source release.

## License

The application code is currently source-available/proprietary. See `LICENSE`.

## AI disclosure

See `AI_DISCLOSURE.md`.
