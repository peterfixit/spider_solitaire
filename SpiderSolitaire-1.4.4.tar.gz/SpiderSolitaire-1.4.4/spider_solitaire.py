#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
import math
import os
import random
import time
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import messagebox, ttk

APP_NAME = "Spider Solitaire"
APP_VERSION = "1.4.4"

SUITS = ["♠", "♥", "♦", "♣"]
SUIT_COLORS = {"♠": "#151515", "♣": "#151515", "♥": "#c62828", "♦": "#c62828"}
RANK_LABELS = {1: "A", 11: "J", 12: "Q", 13: "K"}
DECK_COLORS = {
    "Blue": "#1f5fae",
    "Red": "#b53a46",
    "Green": "#23795a",
    "Purple": "#7046a8",
    "Black": "#202830",
    "Orange": "#c86a1c",
}
DIFFICULTIES = ("Easy", "Normal", "Hard")
SUIT_OPTIONS = {"1 Suit": 1, "2 Suits": 2, "4 Suits": 4}
RUN_OPTIONS = {"8 Runs": 8, "16 Runs": 16}
DRAW_OPTIONS = {"Draw 10": 10, "Draw 3": 3}
BACKGROUND_COLORS = {
    "Classic Green": ("#0b6b4a", "#064936", "#064534", "#7ab596"),
    "Forest": ("#174f3b", "#10382b", "#0d3528", "#719b88"),
    "Midnight Blue": ("#173a5e", "#0d263f", "#102d49", "#7594b0"),
    "Burgundy": ("#6a2d3e", "#431c29", "#4f2230", "#ad7886"),
    "Slate": ("#3e4b56", "#29333b", "#303a43", "#82909b"),
    "Purple": ("#503768", "#352445", "#3c2a4e", "#927ca5"),
    "Teal": ("#12636a", "#0b4146", "#0e4a50", "#78aeb2"),
    "Charcoal": ("#292f34", "#1b2024", "#20262a", "#727b82"),
}


def rank_text(rank: int) -> str:
    return RANK_LABELS.get(rank, str(rank))


def data_dir() -> Path:
    base = os.environ.get("XDG_DATA_HOME")
    if base:
        p = Path(base) / "SpiderSolitaire"
    else:
        p = Path.home() / ".local" / "share" / "SpiderSolitaire"
    p.mkdir(parents=True, exist_ok=True)
    return p


@dataclass
class Card:
    rank: int
    suit: str
    face_up: bool = False

    def to_dict(self):
        return {"rank": self.rank, "suit": self.suit, "face_up": self.face_up}

    @classmethod
    def from_dict(cls, d):
        return cls(int(d["rank"]), str(d["suit"]), bool(d.get("face_up", False)))


class SpiderGame:
    def __init__(self, suits: int = 1, difficulty: str = "Normal", runs: int = 8, draw_count: int = 10):
        self.suits = suits
        self.difficulty = difficulty if difficulty in DIFFICULTIES else "Normal"
        self.target_runs = runs if runs in (8, 16) else 8
        self.draw_count = draw_count if draw_count in (3, 10) else 10
        self.deal_cursor = 0
        self.tableau: list[list[Card]] = [[] for _ in range(10)]
        self.stock: list[Card] = []
        self.completed: list[str] = []
        self.moves = 0
        self.history: list[dict] = []
        self.timer_started = False
        self.start_time: float | None = None
        self.end_time: float | None = None
        self.new_game(suits, self.difficulty, self.target_runs, self.draw_count)

    @staticmethod
    def _base_cards(suits: int, runs: int) -> list[Card]:
        if suits == 1:
            chosen = ["♠"]
        elif suits == 2:
            chosen = ["♠", "♥"]
        else:
            chosen = SUITS
        repeats = runs // len(chosen)
        return [Card(rank, suit, False) for _ in range(repeats) for suit in chosen for rank in range(1, 14)]

    @staticmethod
    def _opening_extra_cols(runs: int) -> int:
        # 8-run Spider uses the classic 54-card opening (4 columns receive the
        # sixth card). 16-run mode uses 58 cards so the remaining 150 cards make
        # exactly fifteen standard 10-card stock deals.
        return 4 if runs == 8 else 8

    @classmethod
    def _preview_deal(cls, deck: list[Card], runs: int) -> tuple[list[list[Card]], list[Card]]:
        work = list(deck)
        tableau: list[list[Card]] = [[] for _ in range(10)]
        extra_cols = cls._opening_extra_cols(runs)
        for row in range(6):
            for col in range(10):
                if row == 5 and col >= extra_cols:
                    continue
                tableau[col].append(work.pop())
        return tableau, work

    @classmethod
    def _deal_score(cls, deck: list[Card], runs: int, draw_count: int) -> int:
        """Heuristic favourability score used only to bias Easy/Hard deals.

        Higher scores produce more same-suit descending opportunities in the
        initial tableau and in the stock sequence. Normal uses an unbiased
        shuffle; Easy samples many shuffles and picks a friendlier one; Hard
        picks a less friendly one. The move rules themselves never change.
        """
        tableau, stock = cls._preview_deal(deck, runs)
        score = 0

        # Initial exposed-card mobility and same-suit build opportunities.
        tops = [col[-1] for col in tableau]
        for i, src in enumerate(tops):
            for j, dst in enumerate(tops):
                if i == j:
                    continue
                if dst.rank == src.rank + 1:
                    score += 4
                    if dst.suit == src.suit:
                        score += 14

        # Reward useful descending adjacency throughout the dealt columns.
        # These cards become relevant as hidden cards are exposed later.
        for col in tableau:
            for lower, upper in zip(col, col[1:]):
                if lower.rank == upper.rank + 1:
                    score += 2
                    if lower.suit == upper.suit:
                        score += 8
                elif abs(lower.rank - upper.rank) >= 7:
                    score -= 1

        # Estimate stock friendliness using the selected deal size. Draw 3
        # rotates across columns, so the heuristic follows the same order.
        sim_tops = list(tops)
        work = list(stock)
        cursor = 0
        while work:
            count = min(draw_count, len(work))
            for offset in range(count):
                col = (cursor + offset) % 10
                new = work.pop()
                old = sim_tops[col]
                if old.rank == new.rank + 1:
                    score += 3
                    if old.suit == new.suit:
                        score += 11
                elif new.rank == old.rank + 1:
                    score += 1
                    if old.suit == new.suit:
                        score += 3
                sim_tops[col] = new
            cursor = (cursor + count) % 10
        return score

    def _deck(self, suits: int, difficulty: str, runs: int, draw_count: int) -> list[Card]:
        base = self._base_cards(suits, runs)
        if difficulty == "Normal":
            random.shuffle(base)
            return base

        # Pick from a population of genuine random shuffles rather than changing
        # the rules. This meaningfully shifts the chance of a playable deal while
        # still producing a different random game every time.
        candidate_count = 240 if suits == 4 else 180
        best_deck = None
        best_score = None
        choose_high = difficulty == "Easy"
        for _ in range(candidate_count):
            candidate = [Card(c.rank, c.suit, False) for c in base]
            random.shuffle(candidate)
            score = self._deal_score(candidate, runs, draw_count)
            if best_score is None or (choose_high and score > best_score) or (not choose_high and score < best_score):
                best_deck = candidate
                best_score = score
        return best_deck if best_deck is not None else base

    def new_game(self, suits: int | None = None, difficulty: str | None = None, runs: int | None = None, draw_count: int | None = None):
        if suits is not None:
            self.suits = suits
        if difficulty is not None and difficulty in DIFFICULTIES:
            self.difficulty = difficulty
        if runs is not None and runs in (8, 16):
            self.target_runs = runs
        if draw_count is not None and draw_count in (3, 10):
            self.draw_count = draw_count
        deck = self._deck(self.suits, self.difficulty, self.target_runs, self.draw_count)
        self.tableau = [[] for _ in range(10)]
        self.stock = []
        self.completed = []
        self.moves = 0
        self.history = []
        self.deal_cursor = 0
        self.timer_started = False
        self.start_time = None
        self.end_time = None

        # 8 runs: classic 54-card opening / 50-card stock.
        # 16 runs: 58-card opening / 150-card stock (15 deals).
        extra_cols = self._opening_extra_cols(self.target_runs)
        for row in range(6):
            for col in range(10):
                if row == 5 and col >= extra_cols:
                    continue
                card = deck.pop()
                self.tableau[col].append(card)
        for col in self.tableau:
            col[-1].face_up = True
        self.stock = deck

    def snapshot(self) -> dict:
        return {
            "tableau": [[c.to_dict() for c in col] for col in self.tableau],
            "stock": [c.to_dict() for c in self.stock],
            "completed": list(self.completed),
            "target_runs": self.target_runs,
            "draw_count": self.draw_count,
            "deal_cursor": self.deal_cursor,
            "moves": self.moves,
            "timer_started": self.timer_started,
            "elapsed": self.elapsed_seconds(),
            "end_time": self.end_time,
        }

    def restore(self, snap: dict):
        self.tableau = [[Card.from_dict(c) for c in col] for col in snap["tableau"]]
        self.stock = [Card.from_dict(c) for c in snap["stock"]]
        self.completed = list(snap["completed"])
        self.target_runs = int(snap.get("target_runs", self.target_runs))
        self.draw_count = int(snap.get("draw_count", self.draw_count))
        self.deal_cursor = int(snap.get("deal_cursor", self.deal_cursor)) % 10
        self.moves = int(snap["moves"])
        elapsed = int(snap.get("elapsed", 0))
        self.timer_started = bool(snap.get("timer_started", self.moves > 0))
        self.start_time = (time.time() - elapsed) if self.timer_started else None
        self.end_time = snap.get("end_time")

    def push_history(self):
        self.history.append(copy.deepcopy(self.snapshot()))
        if len(self.history) > 500:
            self.history.pop(0)

    def undo(self) -> bool:
        if not self.history:
            return False
        # Once the first tableau move has started the clock, undoing must not
        # reset it back to 0:00. Preserve the live elapsed time across history.
        was_started = self.timer_started
        elapsed_before_undo = self.elapsed_seconds()
        self.restore(self.history.pop())
        if was_started:
            self.timer_started = True
            self.start_time = time.time() - elapsed_before_undo
        self.end_time = None
        return True

    def start_timer(self):
        if not self.timer_started:
            self.timer_started = True
            self.start_time = time.time()

    def elapsed_seconds(self) -> int:
        if not self.timer_started or self.start_time is None:
            return 0
        if self.end_time is not None:
            return max(0, int(self.end_time - self.start_time))
        return max(0, int(time.time() - self.start_time))

    def movable_sequence(self, col_idx: int, card_idx: int) -> bool:
        col = self.tableau[col_idx]
        if card_idx < 0 or card_idx >= len(col) or not col[card_idx].face_up:
            return False
        for i in range(card_idx, len(col) - 1):
            a, b = col[i], col[i + 1]
            if not b.face_up or a.suit != b.suit or a.rank != b.rank + 1:
                return False
        return True

    def can_move(self, src_col: int, card_idx: int, dst_col: int) -> bool:
        if src_col == dst_col or not self.movable_sequence(src_col, card_idx):
            return False
        moving = self.tableau[src_col][card_idx]
        dst = self.tableau[dst_col]
        return not dst or (dst[-1].face_up and dst[-1].rank == moving.rank + 1)

    def move(self, src_col: int, card_idx: int, dst_col: int) -> bool:
        if not self.can_move(src_col, card_idx, dst_col):
            return False
        # The clock starts on the first successful tableau move, not when the
        # deal appears and not when the stock is clicked.
        self.start_timer()
        self.push_history()
        moving = self.tableau[src_col][card_idx:]
        del self.tableau[src_col][card_idx:]
        self.tableau[dst_col].extend(moving)
        if self.tableau[src_col] and not self.tableau[src_col][-1].face_up:
            self.tableau[src_col][-1].face_up = True
        self.moves += 1
        self._remove_complete_runs()
        return True

    def can_deal(self) -> bool:
        # Empty columns are allowed. Draw 3 also permits a final partial deal.
        return bool(self.stock)

    def deal(self) -> bool:
        if not self.can_deal():
            return False
        self.push_history()
        count = min(self.draw_count, len(self.stock))
        for offset in range(count):
            col = (self.deal_cursor + offset) % 10
            c = self.stock.pop()
            c.face_up = True
            self.tableau[col].append(c)
        self.deal_cursor = (self.deal_cursor + count) % 10
        self.moves += 1
        self._remove_complete_runs()
        return True

    def deals_remaining(self) -> int:
        if not self.stock:
            return 0
        return math.ceil(len(self.stock) / self.draw_count)

    def _is_complete_run(self, col: list[Card]) -> bool:
        if len(col) < 13:
            return False
        run = col[-13:]
        if any(not c.face_up for c in run):
            return False
        suit = run[0].suit
        return all(c.suit == suit for c in run) and [c.rank for c in run] == list(range(13, 0, -1))

    def _remove_complete_runs(self):
        changed = True
        while changed:
            changed = False
            for col in self.tableau:
                if self._is_complete_run(col):
                    suit = col[-13].suit
                    del col[-13:]
                    self.completed.append(suit)
                    if col and not col[-1].face_up:
                        col[-1].face_up = True
                    changed = True
                    break
        if len(self.completed) == self.target_runs and self.end_time is None:
            self.start_timer()
            self.end_time = time.time()

    @property
    def won(self) -> bool:
        return len(self.completed) == self.target_runs


class StatsStore:
    def __init__(self):
        self.path = data_dir() / "stats.json"
        self.settings_path = data_dir() / "settings.json"
        self.stats = self._load_json(self.path, {})
        default_settings = {
            "difficulty": "Normal",
            "suits": 1,
            "runs": 8,
            "draw_count": 10,
            "deck_color": "Blue",
            "background": "Classic Green",
        }
        self.settings = self._load_json(self.settings_path, default_settings)

        # Migrate the v1.1 setting where "difficulty" actually meant suit count.
        old = self.settings.get("difficulty")
        if old in SUIT_OPTIONS:
            self.settings["suits"] = SUIT_OPTIONS[old]
            self.settings["difficulty"] = "Normal"
        for k, v in default_settings.items():
            self.settings.setdefault(k, v)

        # Preserve older statistics. Pre-1.4.3 keys lacked Runs; pre-1.4.4
        # keys lacked Stock Draw. All older games used standard Draw 10.
        migrated = False
        for old_key, value in list(self.stats.items()):
            parts = old_key.split("|")
            if len(parts) == 2:
                new_key = f"{old_key}|8|10"
            elif len(parts) == 3:
                new_key = f"{old_key}|10"
            else:
                continue
            if new_key not in self.stats:
                self.stats[new_key] = copy.deepcopy(value)
            migrated = True
        if migrated:
            self._save_json(self.path, self.stats)

    @staticmethod
    def _load_json(path: Path, default):
        try:
            with path.open("r", encoding="utf-8") as f:
                obj = json.load(f)
                return obj if isinstance(obj, dict) else copy.deepcopy(default)
        except Exception:
            return copy.deepcopy(default)

    @staticmethod
    def _save_json(path: Path, obj):
        tmp = path.with_suffix(path.suffix + ".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
        tmp.replace(path)

    @staticmethod
    def key(difficulty: str, suits: int, runs: int, draw_count: int) -> str:
        return f"{difficulty}|{suits}|{runs}|{draw_count}"

    def save_settings(self):
        self._save_json(self.settings_path, self.settings)

    def reset_stats(self):
        self.stats = {}
        self._save_json(self.path, self.stats)

    def record_game_started(self, difficulty: str, suits: int, runs: int, draw_count: int):
        d = self.stats.setdefault(self.key(difficulty, suits, runs, draw_count), self._default())
        d["played"] += 1
        self._save_json(self.path, self.stats)

    def record_win(self, difficulty: str, suits: int, runs: int, draw_count: int, seconds: int, moves: int):
        d = self.stats.setdefault(self.key(difficulty, suits, runs, draw_count), self._default())
        d["won"] += 1
        d["current_streak"] += 1
        d["best_streak"] = max(d["best_streak"], d["current_streak"])
        if d.get("best_time") is None or seconds < d["best_time"]:
            d["best_time"] = seconds
        if d.get("fewest_moves") is None or moves < d["fewest_moves"]:
            d["fewest_moves"] = moves
        self._save_json(self.path, self.stats)

    def record_loss(self, difficulty: str, suits: int, runs: int, draw_count: int):
        d = self.stats.setdefault(self.key(difficulty, suits, runs, draw_count), self._default())
        d["current_streak"] = 0
        self._save_json(self.path, self.stats)

    @staticmethod
    def _default():
        return {"played": 0, "won": 0, "best_time": None, "fewest_moves": None, "current_streak": 0, "best_streak": 0}

    def get(self, difficulty: str, suits: int, runs: int, draw_count: int):
        d = self._default()
        d.update(self.stats.get(self.key(difficulty, suits, runs, draw_count), {}))
        return d


class SpiderApp(tk.Tk):
    CARD_FACE = "#fffef9"
    CARD_EDGE = "#aeb8b3"
    SELECT = "#ffca4b"
    TEXT = "#f7fbf9"

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1280x820")
        self.minsize(860, 600)

        self.store = StatsStore()
        difficulty = self.store.settings.get("difficulty", "Normal")
        if difficulty not in DIFFICULTIES:
            difficulty = "Normal"
        suits = int(self.store.settings.get("suits", 1))
        if suits not in (1, 2, 4):
            suits = 1
        runs = int(self.store.settings.get("runs", 8))
        if runs not in (8, 16):
            runs = 8
        draw_count = int(self.store.settings.get("draw_count", 10))
        if draw_count not in (3, 10):
            draw_count = 10
        self.current_difficulty = difficulty
        self.current_suits = suits
        self.current_runs = runs
        self.current_draw_count = draw_count

        self.deck_color_name = self.store.settings.get("deck_color", "Blue")
        if self.deck_color_name not in DECK_COLORS:
            self.deck_color_name = "Blue"
        self.background_name = self.store.settings.get("background", "Classic Green")
        if self.background_name not in BACKGROUND_COLORS:
            self.background_name = "Classic Green"
        self._load_background_theme()

        self.game = SpiderGame(self.current_suits, self.current_difficulty, self.current_runs, self.current_draw_count)
        self.game_counted = False
        self.win_recorded = False
        self.selected: tuple[int, int] | None = None
        self.hints_active = False
        self.hint_moves: list[tuple[int, int, int]] = []
        self.hint_empty_col: int | None = None
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        self.hint_anim_job: str | None = None
        self.hint_board_signature = None
        self.hint_cycle_index = 0
        self.card_rects: dict[tuple[int, int], tuple[int, int, int, int]] = {}
        self.empty_rects: dict[int, tuple[int, int, int, int]] = {}
        self.hitboxes: list[tuple[int, int, int, int, int, int]] = []
        self.stock_box: tuple[int, int, int, int] | None = None
        self._icon_image = None

        # Pointer/drag state. A short press/release remains the existing
        # single-click auto-move; crossing the threshold turns it into a drag.
        self.press_hit: tuple[int, int] | None = None
        self.press_stock = False
        self.drag_source: tuple[int, int] | None = None
        self.drag_start_xy: tuple[int, int] | None = None
        self.drag_pointer_xy: tuple[int, int] | None = None
        self.drag_offset_xy: tuple[float, float] = (0.0, 0.0)
        self.dragging = False
        self.drag_target: int | None = None
        self._draw_up_step = 22

        self._set_window_icon()
        self._build_ui()
        self.bind_all("<Control-z>", lambda e: self.undo())
        self.bind_all("<Escape>", lambda e: self.clear_selection())
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(250, self._tick)
        self.after(50, self._new_game_initial)

    def _load_background_theme(self):
        self.TABLE, self.TABLE_DARK, self.CARD_SHADOW, self.SLOT_EDGE = BACKGROUND_COLORS[self.background_name]

    def _set_window_icon(self):
        try:
            icon_path = Path(__file__).with_name("spider-solitaire.png")
            if icon_path.exists():
                self._icon_image = tk.PhotoImage(file=str(icon_path))
                self.iconphoto(True, self._icon_image)
        except tk.TclError:
            pass

    def _apply_theme(self):
        self._load_background_theme()
        self.configure(bg=self.TABLE_DARK)
        style = ttk.Style(self)
        style.configure("Top.TFrame", background=self.TABLE_DARK)
        style.configure("Top.TLabel", background=self.TABLE_DARK, foreground=self.TEXT)
        if hasattr(self, "top_bar"):
            self.top_bar.configure(bg=self.TABLE_DARK)
        if hasattr(self, "bottom"):
            self.bottom.configure(bg=self.TABLE_DARK)
        if hasattr(self, "hint"):
            self.hint.configure(bg=self.TABLE_DARK)
        if hasattr(self, "canvas"):
            self.canvas.configure(bg=self.TABLE)
        self.draw()

    def _build_ui(self):
        self.configure(bg=self.TABLE_DARK)
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Top.TFrame", background=self.TABLE_DARK)
        style.configure("Top.TLabel", background=self.TABLE_DARK, foreground=self.TEXT, font=("DejaVu Sans", 10, "bold"))
        style.configure("Top.TButton", font=("DejaVu Sans", 10, "bold"), padding=(11, 7), background="#edf1ef", foreground="#10271f", borderwidth=0, relief="flat")
        style.map("Top.TButton", background=[("active", "#ffffff"), ("pressed", "#d8e0dc")])
        style.configure("TCombobox", padding=4)

        self.top_bar = tk.Frame(self, bg=self.TABLE_DARK, padx=10, pady=8)
        self.top_bar.pack(side="top", fill="x")

        row1 = ttk.Frame(self.top_bar, style="Top.TFrame")
        row1.pack(fill="x")
        ttk.Button(row1, text="New Game", command=self.request_new_game, style="Top.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(row1, text="Statistics", command=self.show_statistics, style="Top.TButton").pack(side="left")
        self.status = ttk.Label(row1, text="", style="Top.TLabel")
        self.status.pack(side="right", padx=(12, 0))

        row2 = ttk.Frame(self.top_bar, style="Top.TFrame")
        row2.pack(fill="x", pady=(8, 0))

        ttk.Label(row2, text="Difficulty", style="Top.TLabel").pack(side="left", padx=(0, 5))
        self.diff_var = tk.StringVar(value=self.current_difficulty)
        diff = ttk.Combobox(row2, textvariable=self.diff_var, values=list(DIFFICULTIES), state="readonly", width=8)
        diff.pack(side="left", padx=(0, 12))
        diff.bind("<<ComboboxSelected>>", self.change_difficulty)

        ttk.Label(row2, text="Suits", style="Top.TLabel").pack(side="left", padx=(0, 5))
        suit_label = next(k for k, v in SUIT_OPTIONS.items() if v == self.current_suits)
        self.suit_var = tk.StringVar(value=suit_label)
        suits_box = ttk.Combobox(row2, textvariable=self.suit_var, values=list(SUIT_OPTIONS.keys()), state="readonly", width=8)
        suits_box.pack(side="left", padx=(0, 12))
        suits_box.bind("<<ComboboxSelected>>", self.change_suits)

        ttk.Label(row2, text="Runs", style="Top.TLabel").pack(side="left", padx=(0, 5))
        runs_label = next(k for k, v in RUN_OPTIONS.items() if v == self.current_runs)
        self.runs_var = tk.StringVar(value=runs_label)
        runs_box = ttk.Combobox(row2, textvariable=self.runs_var, values=list(RUN_OPTIONS.keys()), state="readonly", width=8)
        runs_box.pack(side="left", padx=(0, 12))
        runs_box.bind("<<ComboboxSelected>>", self.change_runs)

        ttk.Label(row2, text="Stock", style="Top.TLabel").pack(side="left", padx=(0, 5))
        draw_label = next(k for k, v in DRAW_OPTIONS.items() if v == self.current_draw_count)
        self.draw_var = tk.StringVar(value=draw_label)
        draw_box = ttk.Combobox(row2, textvariable=self.draw_var, values=list(DRAW_OPTIONS.keys()), state="readonly", width=8)
        draw_box.pack(side="left", padx=(0, 12))
        draw_box.bind("<<ComboboxSelected>>", self.change_draw_count)

        ttk.Label(row2, text="Deck", style="Top.TLabel").pack(side="left", padx=(0, 5))
        self.deck_var = tk.StringVar(value=self.deck_color_name)
        deck = ttk.Combobox(row2, textvariable=self.deck_var, values=list(DECK_COLORS.keys()), state="readonly", width=8)
        deck.pack(side="left", padx=(0, 12))
        deck.bind("<<ComboboxSelected>>", self.change_deck_color)

        ttk.Label(row2, text="Background", style="Top.TLabel").pack(side="left", padx=(0, 5))
        self.background_var = tk.StringVar(value=self.background_name)
        bg = ttk.Combobox(row2, textvariable=self.background_var, values=list(BACKGROUND_COLORS.keys()), state="readonly", width=14)
        bg.pack(side="left")
        bg.bind("<<ComboboxSelected>>", self.change_background)

        ttk.Label(row2, text="Draw 3 rotates across columns", style="Top.TLabel").pack(side="right")

        self.canvas = tk.Canvas(self, bg=self.TABLE, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.after_idle(self.draw))
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

        self.bottom = tk.Frame(self, bg=self.TABLE_DARK, padx=10, pady=8)
        self.bottom.pack(fill="x", side="bottom")

        self.back_button = ttk.Button(self.bottom, text="↶  Back", command=self.undo, style="Top.TButton")
        self.back_button.pack(side="left", padx=(0, 8))
        self.hint_button = ttk.Button(self.bottom, text="Hint", command=self.show_hint, style="Top.TButton")
        self.hint_button.pack(side="left", padx=(0, 10))

        self.hint = tk.Label(
            self.bottom,
            bg=self.TABLE_DARK,
            fg="#e3ece7",
            text="Click a movable card for auto-move, or drag a card/packed sequence to a legal column. Click Hint for one suggested move.",
            anchor="w",
            padx=2,
            pady=6,
        )
        self.hint.pack(side="left", fill="x", expand=True)

    def _stats_args(self):
        return self.current_difficulty, self.current_suits, self.current_runs, self.current_draw_count

    def _new_game_initial(self):
        self.store.record_game_started(*self._stats_args())
        self.game_counted = True
        self.draw()

    def _abandon_current_if_needed(self, title: str, message: str) -> bool:
        if self.game.moves > 0 and not self.game.won:
            if not messagebox.askyesno(title, message):
                return False
            self.store.record_loss(*self._stats_args())
        return True

    def request_new_game(self):
        if not self._abandon_current_if_needed("New Game", "Start a new game? The current game will be abandoned."):
            return
        self.start_new_game()

    def start_new_game(self):
        self.game = SpiderGame(self.current_suits, self.current_difficulty, self.current_runs, self.current_draw_count)
        self.selected = None
        self._reset_drag_state()
        self.clear_hints(reset_cycle=True)
        self.win_recorded = False
        self.store.record_game_started(*self._stats_args())
        self.game_counted = True
        self.hint.config(text=f"{self.current_difficulty}, {self.current_suits}-suit, {self.current_runs}-run, Draw {self.current_draw_count}. Click for auto-move or drag to a column; Hint suggests one sensible move at a time.")
        self.draw()

    def change_difficulty(self, _event=None):
        new = self.diff_var.get()
        if new == self.current_difficulty:
            return
        if not self._abandon_current_if_needed("Change Difficulty", f"Start a new {new} game? The current game will be abandoned."):
            self.diff_var.set(self.current_difficulty)
            return
        self.current_difficulty = new
        self.store.settings["difficulty"] = new
        self.store.save_settings()
        self.start_new_game()

    def change_suits(self, _event=None):
        label = self.suit_var.get()
        new_suits = SUIT_OPTIONS.get(label, self.current_suits)
        if new_suits == self.current_suits:
            return
        if not self._abandon_current_if_needed("Change Suits", f"Start a new {label} game? The current game will be abandoned."):
            old_label = next(k for k, v in SUIT_OPTIONS.items() if v == self.current_suits)
            self.suit_var.set(old_label)
            return
        self.current_suits = new_suits
        self.store.settings["suits"] = new_suits
        self.store.save_settings()
        self.start_new_game()

    def change_runs(self, _event=None):
        label = self.runs_var.get()
        new_runs = RUN_OPTIONS.get(label, self.current_runs)
        if new_runs == self.current_runs:
            return
        if not self._abandon_current_if_needed("Change Runs", f"Start a new {label} game? The current game will be abandoned."):
            old_label = next(k for k, v in RUN_OPTIONS.items() if v == self.current_runs)
            self.runs_var.set(old_label)
            return
        self.current_runs = new_runs
        self.store.settings["runs"] = new_runs
        self.store.save_settings()
        self.start_new_game()

    def change_draw_count(self, _event=None):
        label = self.draw_var.get()
        new_draw = DRAW_OPTIONS.get(label, self.current_draw_count)
        if new_draw == self.current_draw_count:
            return
        if not self._abandon_current_if_needed("Change Stock Draw", f"Start a new {label} game? The current game will be abandoned."):
            old_label = next(k for k, v in DRAW_OPTIONS.items() if v == self.current_draw_count)
            self.draw_var.set(old_label)
            return
        self.current_draw_count = new_draw
        self.store.settings["draw_count"] = new_draw
        self.store.save_settings()
        self.start_new_game()

    def change_deck_color(self, _event=None):
        self.deck_color_name = self.deck_var.get()
        self.store.settings["deck_color"] = self.deck_color_name
        self.store.save_settings()
        self.draw()

    def change_background(self, _event=None):
        new = self.background_var.get()
        if new not in BACKGROUND_COLORS:
            return
        self.background_name = new
        self.store.settings["background"] = new
        self.store.save_settings()
        self._apply_theme()

    def _legal_moves(self) -> list[tuple[int, int, int]]:
        moves: list[tuple[int, int, int]] = []
        for src_col, col in enumerate(self.game.tableau):
            for card_idx, card in enumerate(col):
                if not card.face_up or not self.game.movable_sequence(src_col, card_idx):
                    continue
                for dst_col in range(10):
                    if self.game.can_move(src_col, card_idx, dst_col):
                        moves.append((src_col, card_idx, dst_col))
        return moves

    def _board_signature(self):
        return (
            tuple(tuple((c.rank, c.suit, c.face_up) for c in col) for col in self.game.tableau),
            len(self.game.stock),
            tuple(self.game.completed),
        )

    def _sequence_len(self, src_col: int, card_idx: int) -> int:
        return len(self.game.tableau[src_col]) - card_idx

    def _reveals_hidden_card(self, src_col: int, card_idx: int) -> bool:
        col = self.game.tableau[src_col]
        return card_idx > 0 and not col[card_idx - 1].face_up

    def _splits_good_run(self, src_col: int, card_idx: int) -> bool:
        if card_idx <= 0:
            return False
        col = self.game.tableau[src_col]
        prev = col[card_idx - 1]
        moving = col[card_idx]
        return prev.face_up and prev.suit == moving.suit and prev.rank == moving.rank + 1

    @staticmethod
    def _bottom_same_suit_run(col: list[Card]) -> int:
        if not col or not col[-1].face_up:
            return 0
        count = 1
        for i in range(len(col) - 1, 0, -1):
            upper = col[i - 1]
            lower = col[i]
            if upper.face_up and upper.suit == lower.suit and upper.rank == lower.rank + 1:
                count += 1
            else:
                break
        return count

    def _would_complete_run(self, src_col: int, card_idx: int, dst_col: int) -> bool:
        moving = self.game.tableau[src_col][card_idx:]
        combined = self.game.tableau[dst_col] + moving
        if len(combined) < 13:
            return False
        run = combined[-13:]
        suit = run[0].suit
        return all(c.face_up and c.suit == suit for c in run) and [c.rank for c in run] == list(range(13, 0, -1))

    def _move_score(self, src_col: int, card_idx: int, dst_col: int) -> tuple[int, dict]:
        """Score a legal move for both single-click movement and sensible hints.

        The score intentionally favours progress: finishing a run, exposing a
        hidden card, or joining same-suit runs. It penalises dismantling or
        pointlessly relocating long, already organised sequences.
        """
        moving = self.game.tableau[src_col][card_idx]
        dst = self.game.tableau[dst_col]
        seq_len = self._sequence_len(src_col, card_idx)
        reveals = self._reveals_hidden_card(src_col, card_idx)
        splits = self._splits_good_run(src_col, card_idx)
        completes = self._would_complete_run(src_col, card_idx, dst_col)
        empties_source = card_idx == 0
        same_suit = bool(dst) and dst[-1].suit == moving.suit

        score = 0
        if completes:
            score += 6000
        if reveals:
            score += 1200
        if same_suit:
            joined = self._bottom_same_suit_run(dst) + seq_len
            score += 850 + min(joined, 13) * 35
        elif dst:
            score += 130
        else:
            score += 60

        if empties_source:
            score += 180
        if splits:
            score -= 650 if not reveals else 180

        # Small/short moves are usually more useful than hauling a nearly
        # finished sequence around the board. Very long runs are only attractive
        # when they reveal a card or finish a full K-A run.
        score -= max(0, seq_len - 1) * 18
        if seq_len >= 6 and not reveals and not completes:
            score -= 900 + (seq_len - 6) * 90

        # Moving an entire column to another empty column changes almost nothing.
        if not dst and card_idx == 0:
            score -= 1800

        meta = {
            "sequence_len": seq_len,
            "reveals": reveals,
            "splits": splits,
            "completes": completes,
            "same_suit": same_suit,
            "empty_destination": not bool(dst),
            "empties_source": empties_source,
        }
        return score, meta

    def _best_destination_for_source(self, src_col: int, card_idx: int):
        candidates = []
        for dst_col in range(10):
            if not self.game.can_move(src_col, card_idx, dst_col):
                continue
            score, meta = self._move_score(src_col, card_idx, dst_col)
            candidates.append((score, -dst_col, dst_col, meta))
        if not candidates:
            return None
        candidates.sort(reverse=True, key=lambda x: (x[0], x[1]))
        score, _neg_dst, dst_col, meta = candidates[0]
        return score, dst_col, meta

    def _ranked_hint_candidates(self):
        candidates = []
        for src_col, col in enumerate(self.game.tableau):
            for card_idx, card in enumerate(col):
                if not card.face_up or not self.game.movable_sequence(src_col, card_idx):
                    continue
                best = self._best_destination_for_source(src_col, card_idx)
                if best is None:
                    continue
                score, dst_col, meta = best

                # Do not give nuisance hints that dismantle a clean run or move a
                # mostly finished stack merely because the move is technically legal.
                if meta["splits"] and not meta["reveals"] and not meta["completes"]:
                    continue
                if meta["sequence_len"] >= 6 and not meta["reveals"] and not meta["completes"]:
                    continue
                candidates.append((score, src_col, card_idx, dst_col, meta))

        candidates.sort(key=lambda x: (-x[0], x[1], x[2], x[3]))
        return candidates

    def _hint_message_for_move(self, src_col: int, card_idx: int, dst_col: int, meta: dict) -> str:
        moving = self.game.tableau[src_col][card_idx]
        dst = self.game.tableau[dst_col]
        n = meta["sequence_len"]
        item = f"{rank_text(moving.rank)}{moving.suit}"
        if n > 1:
            item += f" stack ({n} cards)"
        if meta["completes"]:
            return f"Hint: move the {item} to column {dst_col + 1} to complete a full run."
        if meta["reveals"]:
            return f"Hint: move the {item} to column {dst_col + 1} to uncover a face-down card."
        if dst and meta["same_suit"]:
            return f"Hint: join the {item} onto {rank_text(dst[-1].rank)}{dst[-1].suit} in column {dst_col + 1}."
        if dst:
            return f"Hint: move the {item} onto {rank_text(dst[-1].rank)}{dst[-1].suit} in column {dst_col + 1}."
        return "You can use an empty slot."

    def show_hint(self):
        signature = self._board_signature()
        if signature != self.hint_board_signature:
            self.hint_board_signature = signature
            self.hint_cycle_index = 0
        else:
            self.hint_cycle_index += 1

        self.clear_hints(reset_cycle=False)
        empty_cols = [i for i, col in enumerate(self.game.tableau) if not col]
        ranked = self._ranked_hint_candidates()

        # Only explicit, genuinely useful moves become normal hints. An empty
        # column is represented by one generic hint rather than by every source
        # card that could legally be dropped there.
        useful = [c for c in ranked if c[0] >= 500 and not c[4]["empty_destination"]]
        critical = [c for c in useful if c[4]["completes"] or c[4]["reveals"]]
        noncritical = [c for c in useful if c not in critical]

        choices = []
        if critical:
            choices.extend(("move", c) for c in critical)
            if empty_cols:
                choices.append(("empty", empty_cols[0]))
            choices.extend(("move", c) for c in noncritical)
        elif empty_cols:
            # With no urgent uncover/finish move, the most useful high-level hint
            # is often simply that an empty workspace is available.
            choices.append(("empty", empty_cols[0]))
            choices.extend(("move", c) for c in noncritical)
        else:
            choices.extend(("move", c) for c in noncritical)

        if choices:
            kind, payload = choices[self.hint_cycle_index % len(choices)]
            if kind == "empty":
                self.hint_moves = []
                self.hint_empty_col = int(payload)
                self.hints_active = True
                self.hint.config(text="You can use an empty slot.")
            else:
                _score, src_col, card_idx, dst_col, meta = payload
                self.hint_moves = [(src_col, card_idx, dst_col)]
                self.hint_empty_col = None
                self.hints_active = True
                self.hint.config(text=self._hint_message_for_move(src_col, card_idx, dst_col, meta))
            self._start_hint_animation()
            self.draw()
            return

        if ranked:
            # No high-value move exists and there is no empty slot. Show only the
            # best reasonable legal move rather than flooding the board.
            chosen = ranked[self.hint_cycle_index % len(ranked)]
            _score, src_col, card_idx, dst_col, meta = chosen
            self.hint_moves = [(src_col, card_idx, dst_col)]
            self.hint_empty_col = None
            self.hints_active = True
            self.hint.config(text=self._hint_message_for_move(src_col, card_idx, dst_col, meta))
            self._start_hint_animation()
            self.draw()
            return

        self.hint.config(text="No useful tableau move is available. Deal another row if you can.")
        self.draw()

    def _start_hint_animation(self):
        self._stop_hint_animation()
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        self.hint_anim_job = self.after(70, self._animate_hint)

    def _animate_hint(self):
        self.hint_anim_job = None
        if not self.hints_active or self.hint_anim_finished:
            return

        next_phase = self.hint_anim_phase + 0.055
        if next_phase >= 1.0:
            self.hint_anim_cycles += 1
            if self.hint_anim_cycles >= 3:
                # Three complete source-to-destination previews are enough.
                # Keep the static source/destination outlines and arrow visible,
                # but remove the moving ghost card so the hint does not loop.
                self.hint_anim_phase = 1.0
                self.hint_anim_finished = True
                self.draw()
                return
            next_phase -= 1.0

        self.hint_anim_phase = next_phase
        self.draw()
        self.hint_anim_job = self.after(70, self._animate_hint)

    def _stop_hint_animation(self):
        if self.hint_anim_job is not None:
            try:
                self.after_cancel(self.hint_anim_job)
            except tk.TclError:
                pass
            self.hint_anim_job = None

    def clear_hints(self, reset_cycle: bool = True):
        self._stop_hint_animation()
        self.hints_active = False
        self.hint_moves = []
        self.hint_empty_col = None
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        if reset_cycle:
            self.hint_board_signature = None
            self.hint_cycle_index = 0

    def clear_selection(self):
        self.selected = None
        self.draw()

    def undo(self):
        if self.game.undo():
            self.selected = None
            self._reset_drag_state()
            self.clear_hints()
            self.win_recorded = False
            self.hint.config(text="Move undone.")
            self.draw()
        else:
            self.hint.config(text="Nothing to undo yet.")

    def _tick(self):
        self._update_status()
        self.after(500, self._tick)

    @staticmethod
    def fmt_time(seconds: int) -> str:
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

    def _update_status(self):
        deals = self.game.deals_remaining()
        self.status.config(
            text=f"{self.current_difficulty} • {self.current_suits} suit{'s' if self.current_suits != 1 else ''} • {self.current_runs} runs • Draw {self.current_draw_count}   |   "
                 f"Moves {self.game.moves}   •   Time {self.fmt_time(self.game.elapsed_seconds())}   •   Deals {deals}   •   Runs {len(self.game.completed)}/{self.game.target_runs}"
        )

    def _layout(self):
        # Card geometry is derived from the live canvas size. There is deliberately
        # no old 92-pixel cap, so maximizing the window now enlarges the entire game.
        w = max(620, self.canvas.winfo_width())
        h = max(390, self.canvas.winfo_height())
        margin = max(10, min(34, int(w * 0.018)))
        gap = max(4, min(18, int(w * 0.007)))
        card_w = int((w - 2 * margin - 9 * gap) / 10)
        card_w = max(54, min(172, card_w))
        card_h = int(card_w * 1.40)
        total_w = card_w * 10 + gap * 9
        x0 = (w - total_w) // 2
        y0 = max(118, int(card_h * 1.12) + 24)
        return w, h, x0, y0, card_w, card_h, gap

    def draw(self):
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("all")
        self.hitboxes.clear()
        self.card_rects.clear()
        self.empty_rects.clear()
        w, h, x0, y0, cw, ch, gap = self._layout()
        self._draw_header_area(w, x0, cw, ch, gap)

        max_cards = max((len(c) for c in self.game.tableau), default=1)
        available = max(150, h - y0 - 18)
        face_down_step = max(8, min(26, int(cw * 0.16)))
        face_up_step = max(16, min(56, int(cw * 0.34)))
        estimated = ch + max(0, max_cards - 1) * face_up_step
        scale = min(1.0, available / max(1, estimated))
        down_step = max(7, int(face_down_step * scale))
        up_step = max(14, int(face_up_step * scale))
        self._draw_up_step = up_step

        for ci, col in enumerate(self.game.tableau):
            x = x0 + ci * (cw + gap)
            if not col:
                self._rounded_rect(x, y0, x + cw, y0 + ch, max(6, cw // 16), outline=self.SLOT_EDGE, width=2, dash=(5, 4))
                self.empty_rects[ci] = (x, y0, x + cw, y0 + ch)
                self.hitboxes.append((x, y0, x + cw, y0 + ch, ci, -1))
                continue
            y = y0
            for idx, card in enumerate(col):
                is_last = idx == len(col) - 1
                next_step = up_step if card.face_up else down_step
                selected = self.selected == (ci, idx)
                self.draw_card(x, y, cw, ch, card, selected=selected)
                self.card_rects[(ci, idx)] = (x, y, x + cw, y + ch)
                hit_bottom = y + (ch if is_last else next_step)
                self.hitboxes.append((x, y, x + cw, hit_bottom, ci, idx))
                y += next_step

        if self.hints_active:
            self._draw_hint_overlays(cw)
        if self.dragging and self.drag_source and self.drag_pointer_xy:
            self._draw_drag_overlay(cw, ch)

        self._update_status()
        if self.game.won and not self.win_recorded:
            self.win_recorded = True
            self.store.record_win(self.current_difficulty, self.current_suits, self.current_runs, self.current_draw_count, self.game.elapsed_seconds(), self.game.moves)
            self.after(100, self.show_win)

    def _draw_hint_overlays(self, cw):
        phase = self.hint_anim_phase
        pulse = 0.5 + 0.5 * math.sin(phase * math.tau)
        source_colour = "#ffd24d"
        target_colour = "#62e49b"
        source_width = max(3, int(cw * 0.026))
        target_width = max(3, int(cw * 0.022))

        # Generic empty-slot hint: one pulsing slot, no forest of source badges.
        if self.hint_empty_col is not None:
            rect = self.empty_rects.get(self.hint_empty_col)
            if rect:
                x1, y1, x2, y2 = rect
                inset = max(3, int(cw * (0.025 + 0.035 * pulse)))
                self._rounded_rect(
                    x1 + inset, y1 + inset, x2 - inset, y2 - inset,
                    max(5, cw // 16), outline=target_colour,
                    width=max(3, int(target_width + pulse * 2)), dash=(7, 3),
                )
                self.canvas.create_text(
                    (x1 + x2) / 2, y1 + max(18, int(cw * 0.17)),
                    text="EMPTY SLOT", fill=target_colour,
                    font=("DejaVu Sans", max(9, int(cw * 0.085)), "bold"),
                )
            return

        if not self.hint_moves:
            return

        # A hint is deliberately one move only. The source and destination are
        # outlined, with a small animated copy of the moving card travelling
        # along the exact single-click path.
        src_col, card_idx, dst_col = self.hint_moves[0]
        src_rect = self.card_rects.get((src_col, card_idx))
        dst_tableau = self.game.tableau[dst_col]
        dst_rect = self.card_rects.get((dst_col, len(dst_tableau) - 1)) if dst_tableau else self.empty_rects.get(dst_col)
        if not src_rect or not dst_rect:
            return

        sx1, sy1, sx2, sy2 = src_rect
        dx1, dy1, dx2, dy2 = dst_rect
        self._rounded_rect(sx1 + 2, sy1 + 2, sx2 - 2, sy2 - 2, max(5, cw // 15), outline=source_colour, width=source_width)
        dinset = max(5, int(cw * 0.045))
        self._rounded_rect(dx1 + dinset, dy1 + dinset, dx2 - dinset, dy2 - dinset, max(4, cw // 17), outline=target_colour, width=target_width, dash=(6, 3))

        sx = (sx1 + sx2) / 2
        sy = (sy1 + sy2) / 2
        dx = (dx1 + dx2) / 2
        dy = (dy1 + dy2) / 2
        self.canvas.create_line(
            sx, sy, dx, dy, fill=target_colour,
            width=max(2, int(cw * 0.018)), dash=(8, 5), arrow=tk.LAST,
            arrowshape=(max(8, int(cw * 0.10)), max(10, int(cw * 0.13)), max(4, int(cw * 0.055))),
        )

        # Animate a full-size copy of the card exactly as it appears in the
        # tableau. After three trips the animation stops, while the static
        # source/destination outlines remain as the hint.
        if not self.hint_anim_finished:
            t = 0.5 - 0.5 * math.cos(math.pi * phase)
            t = 0.08 + 0.84 * t
            mx = sx + (dx - sx) * t
            my = sy + (dy - sy) * t
            hint_w = sx2 - sx1
            hint_h = sy2 - sy1
            moving = self.game.tableau[src_col][card_idx]
            self.draw_card(
                mx - hint_w / 2, my - hint_h / 2,
                hint_w, hint_h, moving, small=False,
            )

    def _draw_header_area(self, w, x0, cw, ch, gap):
        # Large stock pile at left; it scales with the tableau cards.
        sx, sy = x0, 12
        sw, sh = max(74, int(cw * 1.02)), max(104, int(ch * 1.02))
        if self.game.stock:
            layers = min(5, self.game.deals_remaining())
            layer_offset = max(2, int(cw * 0.028))
            for i in range(layers):
                self.draw_back(sx + i * layer_offset, sy, sw, sh)
            self.canvas.create_text(
                sx + sw / 2 + (layers - 1) * layer_offset,
                sy + sh / 2,
                text=str(self.game.deals_remaining()),
                fill="white",
                font=("DejaVu Sans", max(15, int(cw * 0.22)), "bold"),
            )
        else:
            self._rounded_rect(sx, sy, sx + sw, sy + sh, max(6, cw // 16), outline=self.SLOT_EDGE, width=2, dash=(5, 4))
        self.stock_box = (sx, sy, sx + sw + 24, sy + sh)
        self.canvas.create_text(sx + sw / 2, sy + sh + max(12, int(cw * 0.12)), text="DEAL", fill="#f0f6f3", font=("DejaVu Sans", max(9, int(cw * 0.095)), "bold"))

        # Completed runs at right. 16-run games use two rows of eight so the
        # progress display stays readable without shrinking the main cards.
        fw = max(34, int(cw * 0.47))
        fh = max(48, int(ch * 0.47))
        fg = max(3, int(cw * 0.035))
        row_gap = max(3, int(cw * 0.035))
        cols = 8
        total = fw * cols + fg * (cols - 1)
        fx0 = max(x0 + int(cw * 1.75), w - x0 - total)
        for i in range(self.game.target_runs):
            row = i // cols
            col = i % cols
            fx = fx0 + col * (fw + fg)
            fy = sy + row * (fh + row_gap)
            if i < len(self.game.completed):
                c = Card(13, self.game.completed[i], True)
                self.draw_card(fx, fy, fw, fh, c, small=True)
            else:
                self._rounded_rect(fx, fy, fx + fw, fy + fh, max(4, fw // 14), outline=self.SLOT_EDGE, width=1, dash=(4, 3))

    def _rounded_rect(self, x1, y1, x2, y2, r, **kwargs):
        r = max(2, int(r))
        kwargs.setdefault("fill", "")
        points = [
            int(x1+r), int(y1), int(x2-r), int(y1),
            int(x2), int(y1+r), int(x2), int(y2-r),
            int(x2-r), int(y2), int(x1+r), int(y2),
            int(x1), int(y2-r), int(x1), int(y1+r),
        ]
        return self.canvas.create_polygon(points, smooth=False, **kwargs)

    def draw_back(self, x, y, w, h):
        col = DECK_COLORS[self.deck_color_name]
        r = max(5, int(w) // 14)
        shadow = max(1, int(w * 0.022))
        self._rounded_rect(x+shadow, y+shadow*2, x+w+shadow, y+h+shadow*2, r, fill=self.CARD_SHADOW, outline="")
        self._rounded_rect(x, y, x+w, y+h, r, fill=col, outline="#f8faf9", width=max(1, int(w * 0.018)))
        inset = max(5, int(w * 0.10))
        self._rounded_rect(x+inset, y+inset, x+w-inset, y+h-inset, max(3, r-2), outline="#ffffff", width=max(1, int(w * 0.014)))
        inner = inset + max(4, int(w * 0.055))
        self._rounded_rect(x+inner, y+inner, x+w-inner, y+h-inner, max(2, r-3), outline="#e2ebe7", width=1)
        step = max(10, int(w * 0.15))
        left, right = int(x+inner+3), int(x+w-inner-3)
        top, bottom = int(y+inner+3), int(y+h-inner-3)
        for d in range(-int(h), int(w)+int(h), step):
            x1 = max(left, left + d)
            y1 = top + max(0, -d)
            x2 = min(right, left + d + (bottom-top))
            y2 = top + (x2 - (left + d))
            if x1 <= right and y1 <= bottom and x2 >= left and y2 >= top:
                self.canvas.create_line(x1, y1, x2, y2, fill="#edf3f0", width=max(1, int(w * 0.008)))

    def draw_card(self, x, y, w, h, card: Card, selected=False, small=False):
        r = max(4, int(w) // 15)
        if not card.face_up:
            self.draw_back(x, y, w, h)
            return
        outline = self.SELECT if selected else self.CARD_EDGE
        width = max(2, int(w * 0.022)) if selected else max(1, int(w * 0.009))
        shadow = max(1, int(w * 0.02))
        self._rounded_rect(x+shadow, y+shadow*2, x+w+shadow, y+h+shadow*2, r, fill=self.CARD_SHADOW, outline="")
        self._rounded_rect(x, y, x+w, y+h, r, fill=self.CARD_FACE, outline=outline, width=width)
        fg = SUIT_COLORS[card.suit]
        fs = max(9, int(w * (0.17 if small else 0.205)))
        rank_font = ("DejaVu Sans", fs, "bold")
        suit_font = ("DejaVu Sans", max(9, int(w * 0.19)), "bold")
        left = x + max(8, w * 0.13)
        self.canvas.create_text(left, y + max(10, h * 0.095), text=rank_text(card.rank), fill=fg, font=rank_font)
        self.canvas.create_text(left, y + max(24, h * 0.225), text=card.suit, fill=fg, font=suit_font)
        if not small and h >= 70:
            self.canvas.create_text(x+w/2, y+h*0.61, text=card.suit, fill=fg, font=("DejaVu Sans", max(20, int(w*0.42)), "bold"))

    def _auto_destination(self, src_col: int, card_idx: int) -> int | None:
        if not self.game.movable_sequence(src_col, card_idx):
            return None
        best = self._best_destination_for_source(src_col, card_idx)
        return None if best is None else best[1]

    def _hit_test(self, x: int, y: int) -> tuple[int, int] | None:
        for hb in reversed(self.hitboxes):
            x1, y1, x2, y2, col, idx = hb
            if x1 <= x <= x2 and y1 <= y <= y2:
                return col, idx
        return None

    def _column_at_point(self, x: int, y: int) -> int | None:
        _w, _h, x0, y0, cw, _ch, gap = self._layout()
        if y < y0 - 32:
            return None
        for ci in range(10):
            cx = x0 + ci * (cw + gap)
            left = cx - gap / 2
            right = cx + cw + gap / 2
            if left <= x <= right:
                return ci
        return None

    def _reset_drag_state(self):
        self.press_hit = None
        self.press_stock = False
        self.drag_source = None
        self.drag_start_xy = None
        self.drag_pointer_xy = None
        self.drag_offset_xy = (0.0, 0.0)
        self.dragging = False
        self.drag_target = None

    def on_press(self, event):
        x, y = event.x, event.y
        self._reset_drag_state()
        self.drag_start_xy = (x, y)
        self.drag_pointer_xy = (x, y)

        if self.stock_box:
            x1, y1, x2, y2 = self.stock_box
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.press_stock = True
                return

        hit = self._hit_test(x, y)
        self.press_hit = hit
        if hit is None:
            return
        col, idx = hit
        if idx < 0 or idx >= len(self.game.tableau[col]):
            return
        card = self.game.tableau[col][idx]
        if not card.face_up or not self.game.movable_sequence(col, idx):
            return

        self.drag_source = (col, idx)
        rect = self.card_rects.get((col, idx))
        if rect:
            self.drag_offset_xy = (x - rect[0], y - rect[1])
        self.selected = (col, idx)
        self.draw()

    def on_drag(self, event):
        if self.drag_source is None or self.drag_start_xy is None:
            return
        x, y = event.x, event.y
        self.drag_pointer_xy = (x, y)
        if not self.dragging:
            dx = x - self.drag_start_xy[0]
            dy = y - self.drag_start_xy[1]
            threshold = max(7, int(self._layout()[4] * 0.045))
            if math.hypot(dx, dy) < threshold:
                return
            self.dragging = True
            self.clear_hints()

        src_col, card_idx = self.drag_source
        dst = self._column_at_point(x, y)
        self.drag_target = dst if dst is not None and self.game.can_move(src_col, card_idx, dst) else None
        self.draw()

    def on_release(self, event):
        x, y = event.x, event.y

        if self.press_stock and not self.dragging:
            self._reset_drag_state()
            self.selected = None
            self.deal_stock()
            return

        source = self.drag_source
        was_dragging = self.dragging
        press_hit = self.press_hit

        if source is not None and was_dragging:
            src_col, card_idx = source
            dst = self._column_at_point(x, y)
            moved = dst is not None and self.game.can_move(src_col, card_idx, dst) and self.game.move(src_col, card_idx, dst)
            self.selected = None
            self._reset_drag_state()
            self.clear_hints()
            if moved:
                self.hint.config(text=f"Moved to column {dst + 1}. Back or Ctrl+Z will undo it.")
            else:
                self.hint.config(text="That stack cannot be dropped there. It must land on the next higher rank, or an empty column.")
            self.draw()
            return

        self._reset_drag_state()
        self.selected = None
        self._handle_single_click(press_hit)

    def _handle_single_click(self, hit: tuple[int, int] | None):
        if hit is None:
            self.clear_selection()
            return

        col, idx = hit
        if idx < 0:
            self.hint.config(text="Empty column. Drag a movable card/sequence here, or click a card and auto-move will use it when appropriate.")
            self.draw()
            return
        if idx >= len(self.game.tableau[col]):
            return
        card = self.game.tableau[col][idx]
        if not card.face_up:
            self.hint.config(text="That card is face down.")
            self.draw()
            return
        if not self.game.movable_sequence(col, idx):
            self.hint.config(text="Only a descending same-suit packed sequence can move together.")
            self.draw()
            return

        dst = self._auto_destination(col, idx)
        if dst is None:
            self.hint.config(text="No legal destination is available for that card or sequence.")
            self.draw()
            return

        if self.game.move(col, idx, dst):
            self.clear_hints()
            self.hint.config(text=f"Moved to column {dst + 1}. Back or Ctrl+Z will undo it.")
            self.draw()

    def _draw_drag_overlay(self, cw: int, ch: int):
        if not self.drag_source or not self.drag_pointer_xy:
            return
        src_col, card_idx = self.drag_source
        if src_col >= len(self.game.tableau) or card_idx >= len(self.game.tableau[src_col]):
            return

        px, py = self.drag_pointer_xy
        ox, oy = self.drag_offset_xy
        gx, gy = px - ox, py - oy

        # Highlight the exact legal destination under the pointer.
        if self.drag_target is not None:
            dst = self.drag_target
            col = self.game.tableau[dst]
            rect = self.card_rects.get((dst, len(col) - 1)) if col else self.empty_rects.get(dst)
            if rect:
                x1, y1, x2, y2 = rect
                inset = max(3, int(cw * 0.025))
                self._rounded_rect(x1 + inset, y1 + inset, x2 - inset, y2 - inset,
                                   max(5, cw // 16), outline="#62e49b", width=max(3, int(cw * 0.025)), dash=(7, 3))

        # Draw the whole movable sequence, not only the card under the pointer.
        seq = self.game.tableau[src_col][card_idx:]
        step = self._draw_up_step
        for i, card in enumerate(seq):
            self.draw_card(gx, gy + i * step, cw, ch, card, selected=(i == 0))

    def deal_stock(self):
        if not self.game.stock:
            self.hint.config(text="No cards remain in the stock.")
            return
        if self.game.deal():
            self.selected = None
            self.clear_hints()
            self.hint.config(text=("Dealt one card to every column." if self.current_draw_count == 10 else "Dealt 3 cards; the next deal continues from the next column."))
            self.draw()

    def show_win(self):
        win = tk.Toplevel(self)
        win.title("You won!")
        win.transient(self)
        win.resizable(False, False)
        try:
            if self._icon_image is not None:
                win.iconphoto(True, self._icon_image)
        except tk.TclError:
            pass

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="You won!", font=("DejaVu Sans", 18, "bold")).pack(anchor="center", pady=(0, 10))
        ttk.Label(
            frame,
            text=(
                f"Difficulty: {self.current_difficulty}\n"
                f"Suits: {self.current_suits}\n"
                f"Runs: {self.current_runs}\n"
                f"Stock: Draw {self.current_draw_count}\n"
                f"Time: {self.fmt_time(self.game.elapsed_seconds())}\n"
                f"Moves: {self.game.moves}"
            ),
            justify="center",
            font=("DejaVu Sans", 11),
        ).pack(anchor="center", pady=(0, 18))

        buttons = ttk.Frame(frame)
        buttons.pack(anchor="center")

        def new_game_from_win():
            win.destroy()
            self.start_new_game()

        ttk.Button(buttons, text="New Game", command=new_game_from_win, style="Top.TButton").pack(side="left", padx=(0, 10))
        ttk.Button(buttons, text="OK", command=win.destroy, style="Top.TButton").pack(side="left")
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        win.bind("<Return>", lambda _e: win.destroy())
        win.bind("<Escape>", lambda _e: win.destroy())
        win.update_idletasks()
        x = self.winfo_rootx() + max(0, (self.winfo_width() - win.winfo_reqwidth()) // 2)
        y = self.winfo_rooty() + max(0, (self.winfo_height() - win.winfo_reqheight()) // 2)
        win.geometry(f"+{x}+{y}")
        win.grab_set()
        win.focus_force()

    def show_statistics(self):
        win = tk.Toplevel(self)
        win.title("Statistics")
        win.transient(self)
        win.resizable(True, True)
        win.minsize(900, 480)
        frame = ttk.Frame(win, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Spider Solitaire Statistics", font=("DejaVu Sans", 15, "bold")).grid(row=0, column=0, columnspan=10, sticky="w", pady=(0, 12))
        headers = ["Difficulty", "Suits", "Runs", "Stock", "Played", "Won", "Win rate", "Best time", "Fewest moves", "Best streak"]
        for c, text in enumerate(headers):
            ttk.Label(frame, text=text, font=("DejaVu Sans", 9, "bold")).grid(row=1, column=c, padx=6, pady=4, sticky="w")
        row = 2
        for difficulty in DIFFICULTIES:
            for suit_label, suits in SUIT_OPTIONS.items():
                for runs_label, runs in RUN_OPTIONS.items():
                    for draw_label, draw_count in DRAW_OPTIONS.items():
                        st = self.store.get(difficulty, suits, runs, draw_count)
                        rate = f"{(100*st['won']/st['played']):.1f}%" if st["played"] else "0.0%"
                        vals = [difficulty, suit_label, runs, draw_label, st["played"], st["won"], rate, self.fmt_time(st["best_time"]) if st["best_time"] is not None else "—", st["fewest_moves"] if st["fewest_moves"] is not None else "—", st["best_streak"]]
                        for c, val in enumerate(vals):
                            ttk.Label(frame, text=str(val)).grid(row=row, column=c, padx=6, pady=4, sticky="w")
                        row += 1
        buttons = ttk.Frame(frame)
        buttons.grid(row=row, column=0, columnspan=10, sticky="e", pady=(14, 0))
        ttk.Button(buttons, text="Reset Statistics", command=lambda: self._reset_stats(win)).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Close", command=win.destroy).pack(side="left")

    def _reset_stats(self, win):
        if messagebox.askyesno("Reset Statistics", "Reset all Spider Solitaire statistics?", parent=win):
            self.store.reset_stats()
            win.destroy()
            self.show_statistics()

    def on_close(self):
        self._stop_hint_animation()
        self.store.settings["difficulty"] = self.current_difficulty
        self.store.settings["suits"] = self.current_suits
        self.store.settings["runs"] = self.current_runs
        self.store.settings["draw_count"] = self.current_draw_count
        self.store.settings["deck_color"] = self.deck_color_name
        self.store.settings["background"] = self.background_name
        self.store.save_settings()
        self.destroy()


if __name__ == "__main__":
    app = SpiderApp()
    app.mainloop()
