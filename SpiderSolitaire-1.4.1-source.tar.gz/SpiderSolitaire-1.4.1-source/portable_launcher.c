#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <limits.h>

static const unsigned char MAGIC[8] = {'S','P','D','R','P','A','K','1'};

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    size_t len = strlen(path);
    if (len >= sizeof(tmp)) return -1;
    memcpy(tmp, path, len + 1);
    if (len && tmp[len-1] == '/') tmp[len-1] = 0;
    for (char *p = tmp + 1; *p; ++p) {
        if (*p == '/') {
            *p = 0;
            if (mkdir(tmp, 0755) && errno != EEXIST) return -1;
            *p = '/';
        }
    }
    if (mkdir(tmp, 0755) && errno != EEXIST) return -1;
    return 0;
}

static int extract_payload(const char *self, const char *dest, uint64_t payload_off, uint64_t payload_size) {
    int pfd[2];
    if (pipe(pfd) != 0) return -1;
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        close(pfd[1]);
        if (dup2(pfd[0], STDIN_FILENO) < 0) _exit(126);
        close(pfd[0]);
        execlp("tar", "tar", "-xzf", "-", "-C", dest, (char *)NULL);
        _exit(127);
    }
    close(pfd[0]);
    int fd = open(self, O_RDONLY);
    if (fd < 0 || lseek(fd, (off_t)payload_off, SEEK_SET) < 0) {
        close(pfd[1]);
        if (fd >= 0) close(fd);
        waitpid(pid, NULL, 0);
        return -1;
    }
    unsigned char buf[65536];
    uint64_t left = payload_size;
    while (left) {
        size_t want = left > sizeof(buf) ? sizeof(buf) : (size_t)left;
        ssize_t n = read(fd, buf, want);
        if (n <= 0) break;
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(pfd[1], buf + off, (size_t)(n - off));
            if (w <= 0) { left = 0; break; }
            off += w;
        }
        if ((uint64_t)n <= left) left -= (uint64_t)n; else left = 0;
    }
    close(fd);
    close(pfd[1]);
    int status = 0;
    waitpid(pid, &status, 0);
    return WIFEXITED(status) && WEXITSTATUS(status) == 0 ? 0 : -1;
}

int main(int argc, char **argv) {
    char self[PATH_MAX];
    ssize_t slen = readlink("/proc/self/exe", self, sizeof(self)-1);
    if (slen < 0) { perror("readlink"); return 1; }
    self[slen] = 0;

    int fd = open(self, O_RDONLY);
    if (fd < 0) { perror("open"); return 1; }
    off_t end = lseek(fd, 0, SEEK_END);
    if (end < 16 || lseek(fd, end - 16, SEEK_SET) < 0) { close(fd); return 1; }
    unsigned char footer[16];
    if (read(fd, footer, sizeof(footer)) != sizeof(footer)) { close(fd); return 1; }
    close(fd);
    if (memcmp(footer, MAGIC, 8) != 0) {
        fprintf(stderr, "Spider Solitaire: embedded payload is missing.\n");
        return 1;
    }
    uint64_t size = 0;
    for (int i=0; i<8; ++i) size |= ((uint64_t)footer[8+i]) << (8*i);
    if (size > (uint64_t)(end - 16)) return 1;
    uint64_t payload_off = (uint64_t)end - 16 - size;

    const char *home = getenv("HOME");
    if (!home) home = "/tmp";
    const char *xdg = getenv("XDG_CACHE_HOME");
    char cache[PATH_MAX];
    if (xdg && *xdg) snprintf(cache, sizeof(cache), "%s/SpiderSolitaire/1.4.1-%llu", xdg, (unsigned long long)size);
    else snprintf(cache, sizeof(cache), "%s/.cache/SpiderSolitaire/1.4.1-%llu", home, (unsigned long long)size);
    if (mkdir_p(cache) != 0) { perror("mkdir"); return 1; }

    char marker[PATH_MAX];
    snprintf(marker, sizeof(marker), "%s/.ready", cache);
    if (access(marker, F_OK) != 0) {
        if (extract_payload(self, cache, payload_off, size) != 0) {
            fprintf(stderr, "Spider Solitaire: could not extract the embedded runtime. Ensure 'tar' is installed.\n");
            return 1;
        }
        int m = open(marker, O_CREAT|O_WRONLY|O_TRUNC, 0644);
        if (m >= 0) { write(m, "ok\n", 3); close(m); }
    }

    char apprun[PATH_MAX];
    snprintf(apprun, sizeof(apprun), "%s/SpiderSolitaire.AppDir/AppRun", cache);
    setenv("APPIMAGE", self, 1);

    if (argc > 1 && strcmp(argv[1], "--appimage-extract") == 0) {
        printf("%s/SpiderSolitaire.AppDir\n", cache);
        return 0;
    }

    char **newargv = calloc((size_t)argc + 1, sizeof(char*));
    if (!newargv) return 1;
    newargv[0] = apprun;
    for (int i=1; i<argc; ++i) newargv[i] = argv[i];
    newargv[argc] = NULL;
    execv(apprun, newargv);
    perror("execv");
    return 1;
}
